/* ══════════════════════════════════════
   Dennis's Arcade Library – script.js
   localStorage 기반 풀스택 시뮬레이션
   ══════════════════════════════════════ */

/* ══════════════════════════════════════
   Wave background animation
   ══════════════════════════════════════ */
(function () {
  const canvas = document.getElementById('waveCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let W, H;
  function resize() {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize, { passive: true });

  /* Wave layers: amp, freq, speed, baseY (0–1), two colors for light/dark */
  const layers = [
    { amp: 72,  freq: 0.010, speed: 0.28, yRatio: 0.30 },
    { amp: 55,  freq: 0.016, speed: 0.45, yRatio: 0.50 },
    { amp: 65,  freq: 0.008, speed: 0.20, yRatio: 0.65 },
    { amp: 40,  freq: 0.022, speed: 0.60, yRatio: 0.80 },
  ];

  function isDark() {
    return document.documentElement.getAttribute('data-theme') === 'dark';
  }

  function waveColor(i, dark) {
    /* Dark: deep blues / indigo. Light: soft sky blues */
    const darkColors  = ['rgba(60,100,220,0.22)', 'rgba(30,70,200,0.18)', 'rgba(80,130,240,0.16)', 'rgba(20,50,180,0.13)'];
    const lightColors = ['rgba(100,160,255,0.18)', 'rgba(70,130,240,0.14)', 'rgba(120,180,255,0.12)', 'rgba(50,110,220,0.10)'];
    return dark ? darkColors[i] : lightColors[i];
  }

  let t = 0;
  let scrollY = 0;
  window.addEventListener('scroll', () => { scrollY = window.scrollY; }, { passive: true });

  function draw() {
    ctx.clearRect(0, 0, W, H);
    const dark = isDark();
    const scrollShift = scrollY * 0.0008;

    layers.forEach((lyr, i) => {
      /* Base Y shifts slightly downward as you scroll (parallax feel) */
      const baseY = H * lyr.yRatio + scrollY * 0.06 * (i * 0.5 + 0.4);

      ctx.beginPath();
      ctx.moveTo(0, H + 20);

      for (let x = 0; x <= W + 4; x += 3) {
        const phase = x * lyr.freq + t * lyr.speed;
        const y = baseY
          + Math.sin(phase + scrollShift * (i + 1)) * lyr.amp
          + Math.sin(phase * 0.53 + t * lyr.speed * 0.6) * lyr.amp * 0.38
          + Math.sin(phase * 1.7  + t * lyr.speed * 1.3) * lyr.amp * 0.15;
        ctx.lineTo(x, y);
      }

      ctx.lineTo(W + 4, H + 20);
      ctx.closePath();
      ctx.fillStyle = waveColor(i, dark);
      ctx.fill();
    });

    t += 0.012;
    requestAnimationFrame(draw);
  }

  draw();
})();

/* ── Data helpers ── */
function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) || fallback; }
  catch { return fallback; }
}
function save(key, data) { localStorage.setItem(key, JSON.stringify(data)); }
function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
/* ── Coin helpers ── */
function getUserCoins() {
  const u = users.find(u => u.id === currentUser?.id);
  return u ? (u.coins ?? 0) : 0;
}
function addCoins(n) {
  if (!currentUser) return;
  const u = users.find(u => u.id === currentUser.id);
  if (!u) return;
  u.coins = (u.coins ?? 0) + n;
  save('dal_users', users);
  updateCoinDisplay();
}
function updateCoinDisplay() {
  const el = $('#coinDisplay');
  if (el) el.textContent = currentUser ? `🪙 ${getUserCoins()}` : '';
}

function escapeHTML(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}
function timeAgo(ts) {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return '방금 전';
  if (m < 60) return `${m}분 전`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}시간 전`;
  const d = Math.floor(h / 24);
  return `${d}일 전`;
}
function formatDate(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

/* ── Toast notification ── */
function showToast(msg) {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

/* ── Persistent state ── */
let users = load('dal_users', []);
let currentUser = load('dal_currentUser', null);
let boardPosts = load('dal_posts', [
  { id: 'seed1', author: '달빛독자', authorId: null, content: '첫 화 분위기 너무 좋아요. 다음 화 기대됩니다!', createdAt: Date.now() - 3600000, likes: [], comments: [] },
  { id: 'seed2', author: '작은별', authorId: null, content: '문장 리듬이 좋아서 금방 몰입했어요.', createdAt: Date.now() - 7200000, likes: [], comments: [] },
]);
let bookmarks = load('dal_bookmarks', []);

/* Visit tracking */
const visits = load('dal_visits', []);
visits.push({ ts: Date.now(), page: location.pathname });
save('dal_visits', visits.slice(-500));

/* ── Novel data (static) ── */
const novels = [
  {
    id: 'novel1',
    title: '유리 별의 도시',
    category: 'all',
    summary: '회색 도시 위로 떠오르는 유리 별을 따라가는 소년의 성장기.',
    link: 'novel-detail.html',
  },
];
const categoryNames = { all: '연재중' };

/* ── DOM refs (safe – null-checks everywhere) ── */
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const novelList = $('#novelList');
const categoryButtons = $$('.category-btn');
const boardForm = $('#boardForm');
const boardMessage = $('#boardMessage');
const boardList = $('#boardList');
const novelSearchInput = $('#novelSearchInput');
const newsletterForm = $('#newsletterForm');
const newsletterMessage = $('#newsletterMessage');

const loginDialog = $('#loginDialog');
const signupDialog = $('#signupDialog');
const mypageDialog = $('#mypageDialog');
const closeLoginDialog = $('#closeLoginDialog');
const closeSignupDialog = $('#closeSignupDialog');
const closeMypageDialog = $('#closeMypageDialog');
const loginForm = $('#loginForm');
const signupForm = $('#signupForm');
const loginMessage = $('#loginMessage');
const signupMessage = $('#signupMessage');

let activeCategory = 'all';
let searchKeyword = '';
let boardPageSize = 5;
let boardShowCount = boardPageSize;
let boardSort = 'newest';

/* ══════════════════════════════════════
   0. Dark mode
   ══════════════════════════════════════ */
function initTheme() {
  const saved = localStorage.getItem('dal_theme');
  if (saved === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
  updateThemeIcons();
}

function toggleTheme() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  if (isDark) {
    document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('dal_theme', 'light');
  } else {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('dal_theme', 'dark');
  }
  updateThemeIcons();
}

function updateThemeIcons() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  $$('.theme-icon').forEach(el => el.textContent = isDark ? '☀️' : '🌙');
}

$$('.theme-toggle').forEach(btn => btn.addEventListener('click', toggleTheme));
initTheme();

/* ══════════════════════════════════════
   1. Auth system
   ══════════════════════════════════════ */
function updateAuthUI() {
  const loggedIn = !!currentUser;
  $$('.show-logged-in').forEach(el => el.style.display = loggedIn ? '' : 'none');
  $$('.show-logged-out').forEach(el => el.style.display = loggedIn ? 'none' : '');
  const nameEl = $('#currentUserName');
  if (nameEl && currentUser) nameEl.textContent = currentUser.nickname;

  /* Admin link: only show for admin role */
  $$('.admin-link').forEach(el => {
    el.style.display = (loggedIn && currentUser.role === 'admin') ? '' : 'none';
  });

  /* Board form: show/hide based on login */
  updateBoardFormUI();
  updateCoinDisplay();
}

function updateBoardFormUI() {
  if (!boardForm) return;
  const authorInput = boardForm.querySelector('input[name="author"]');
  const contentInput = boardForm.querySelector('textarea[name="content"]');
  const submitBtn = boardForm.querySelector('button[type="submit"]');

  if (currentUser) {
    if (authorInput) { authorInput.value = currentUser.nickname; authorInput.readOnly = true; }
    if (contentInput) contentInput.disabled = false;
    if (submitBtn) submitBtn.disabled = false;
    /* Remove login prompt if exists */
    boardForm.querySelector('.board-login-prompt')?.remove();
  } else {
    if (authorInput) { authorInput.value = ''; authorInput.readOnly = false; }
  }
}

/* Signup */
signupForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  const fd = new FormData(signupForm);
  const nickname = fd.get('nickname').trim();
  const email = fd.get('email').trim();
  const password = fd.get('signupPassword');

  if (!nickname || !email || !password) { signupMessage.textContent = '모든 항목을 입력해주세요.'; return; }
  if (password.length < 4) { signupMessage.textContent = '비밀번호는 4자 이상이어야 합니다.'; return; }
  if (users.find(u => u.email === email)) { signupMessage.textContent = '이미 등록된 이메일입니다.'; return; }

  const user = { id: genId(), nickname, email, password, role: 'user', banned: false, createdAt: Date.now(), coins: 100 };
  users.push(user);
  save('dal_users', users);

  currentUser = { id: user.id, nickname: user.nickname, email: user.email, role: user.role };
  save('dal_currentUser', currentUser);

  showToast(`${nickname}님, 가입 완료! 자동 로그인되었어요.`);
  setTimeout(() => { signupDialog.close(); signupForm.reset(); updateAuthUI(); renderBoardPosts(); }, 600);
});

/* Login */
loginForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  const fd = new FormData(loginForm);
  const email = fd.get('loginEmail').trim();
  const password = fd.get('password');

  const user = users.find(u => u.email === email && u.password === password);
  if (!user) { loginMessage.textContent = '이메일 또는 비밀번호가 틀렸습니다.'; return; }
  if (user.banned) { loginMessage.textContent = '정지된 계정입니다. 관리자에게 문의하세요.'; return; }

  currentUser = { id: user.id, nickname: user.nickname, email: user.email, role: user.role };
  save('dal_currentUser', currentUser);

  showToast(`${user.nickname}님, 환영합니다!`);
  setTimeout(() => { loginDialog.close(); loginForm.reset(); updateAuthUI(); renderBoardPosts(); }, 500);
});

/* Logout */
$$('.logout-btn').forEach(btn => btn.addEventListener('click', () => {
  currentUser = null;
  save('dal_currentUser', null);
  updateAuthUI();
  renderBoardPosts();
  if (mypageDialog?.open) mypageDialog.close();
  showToast('로그아웃되었습니다.');
}));

/* Open dialogs */
$$('.open-login').forEach(b => b.addEventListener('click', () => { loginMessage && (loginMessage.textContent = ''); loginDialog?.showModal(); }));
$$('.open-signup').forEach(b => b.addEventListener('click', () => { signupMessage && (signupMessage.textContent = ''); signupDialog?.showModal(); }));
$$('.open-mypage').forEach(b => b.addEventListener('click', () => { renderMypage(); mypageDialog?.showModal(); }));

closeLoginDialog?.addEventListener('click', () => loginDialog.close());
closeSignupDialog?.addEventListener('click', () => signupDialog.close());
closeMypageDialog?.addEventListener('click', () => mypageDialog.close());

[loginDialog, signupDialog, mypageDialog].forEach(d => {
  d?.addEventListener('click', (e) => { if (e.target === d) d.close(); });
});

/* ══════════════════════════════════════
   2. Mypage – Save Data / Inventory
   ══════════════════════════════════════ */
function renderMypage() {
  if (!currentUser) return;
  const el = $('#mypageContent');
  if (!el) return;

  const myPosts = boardPosts.filter(p => p.authorId === currentUser.id);
  const myLikes = boardPosts.filter(p => p.likes.includes(currentUser.id));
  const myBookmarks = bookmarks.filter(b => b.userId === currentUser.id);

  /* Inventory items: liked posts become collectible cards */
  const inventoryItems = myLikes.slice(0, 12).map((p, i) => {
    const icons = ['📖','✨','⚡','🌙','🔥','💫','🎮','🗡','🛡','🌀','💎','🃏'];
    return `<div class="inv-item" title="${escapeHTML(p.content.slice(0, 60))}">
      <div class="inv-icon">${icons[i % icons.length]}</div>
      <div class="inv-label">${escapeHTML(p.author.slice(0, 8))}</div>
    </div>`;
  }).join('');

  el.innerHTML = `
    <div class="savedata-header">
      <div class="savedata-slot">SAVE DATA — SLOT 01</div>
      <div class="savedata-profile">
        <div class="avatar-pixel">${escapeHTML(currentUser.nickname.charAt(0))}</div>
        <div class="savedata-info">
          <div class="savedata-name">${escapeHTML(currentUser.nickname)}</div>
          <div class="savedata-sub">${escapeHTML(currentUser.email)}</div>
          <div class="savedata-role-badge">${currentUser.role === 'admin' ? '★ ADMIN' : '▶ PLAYER'}</div>
        </div>
      </div>
      <div class="savedata-stats">
        <div class="stat-chip">📝 ${myPosts.length}<span>POSTS</span></div>
        <div class="stat-chip">♥ ${myLikes.length}<span>LIKES</span></div>
        <div class="stat-chip">★ ${myBookmarks.length}<span>SAVES</span></div>
      </div>
    </div>

    <form id="profileEditForm" class="profile-edit-form">
      <label style="font-size:0.82rem">닉네임 <input type="text" name="newNickname" value="${escapeHTML(currentUser.nickname)}" required /></label>
      <button type="submit" class="btn primary">저장</button>
    </form>
    <form id="passwordChangeForm" class="profile-edit-form">
      <label style="font-size:0.82rem">현재 PW <input type="password" name="currentPw" placeholder="현재 비밀번호" required /></label>
      <label style="font-size:0.82rem">새 PW <input type="password" name="newPw" placeholder="4자 이상" required minlength="4" /></label>
      <button type="submit" class="btn primary">변경</button>
    </form>

    <div class="mypage-section">
      <h4>🪙 코인 잔액</h4>
      <div class="coin-info">
        <span class="coin-balance">🪙 ${getUserCoins()} 코인</span>
        <div class="coin-charge-btns">
          <button class="btn ghost btn-sm coin-charge-btn" data-amount="100">+100</button>
          <button class="btn ghost btn-sm coin-charge-btn" data-amount="500">+500</button>
          <button class="btn primary btn-sm coin-charge-btn" data-amount="1000">+1000 ★</button>
        </div>
        <p class="coin-note">※ 현재 시뮬레이션 코인입니다. 실제 결제와 무관합니다.</p>
      </div>
    </div>

    <div class="mypage-section">
      <h4>🎒 INVENTORY — 수집한 명글 (${myLikes.length})</h4>
      ${myLikes.length === 0
        ? '<p class="empty-state inv-empty">아직 수집한 아이템이 없습니다.<br>게시글에 좋아요를 눌러 수집하세요!</p>'
        : `<div class="inv-grid">${inventoryItems}${myLikes.length > 12 ? `<div class="inv-item inv-more">+${myLikes.length - 12}<div class="inv-label">MORE</div></div>` : ''}</div>`
      }
    </div>

    <div class="mypage-section">
      <h4>★ 북마크한 소설 (${myBookmarks.length})</h4>
      ${myBookmarks.length === 0 ? '<p class="empty-state">북마크한 소설이 없습니다.</p>' :
        myBookmarks.map(b => `<div class="mypage-item">📖 ${escapeHTML(b.title)}</div>`).join('')}
    </div>

    <div class="mypage-section">
      <h4>내가 쓴 글 (${myPosts.length})</h4>
      ${myPosts.length === 0 ? '<p class="empty-state">아직 작성한 글이 없습니다.</p>' :
        myPosts.slice(0, 5).map(p => `<div class="mypage-item">${escapeHTML(p.content.slice(0, 60))}${p.content.length > 60 ? '...' : ''}</div>`).join('')}
    </div>
  `;

  /* Coin charge buttons */
  el.querySelectorAll('.coin-charge-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const amount = parseInt(btn.dataset.amount);
      addCoins(amount);
      showToast(`🪙 ${amount} 코인이 충전되었습니다!`);
      renderMypage();
    });
  });

  /* Nickname edit */
  $('#profileEditForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const newName = new FormData(e.target).get('newNickname').trim();
    if (!newName) return;
    const user = users.find(u => u.id === currentUser.id);
    if (user) { user.nickname = newName; save('dal_users', users); }
    currentUser.nickname = newName;
    save('dal_currentUser', currentUser);
    updateAuthUI();
    renderMypage();
    renderBoardPosts();
    showToast('닉네임이 변경되었습니다.');
  });

  /* Password change */
  $('#passwordChangeForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const currentPw = fd.get('currentPw');
    const newPw = fd.get('newPw');
    const user = users.find(u => u.id === currentUser.id);
    if (!user) return;
    if (user.password !== currentPw) { showToast('현재 비밀번호가 일치하지 않습니다.'); return; }
    if (newPw.length < 4) { showToast('새 비밀번호는 4자 이상이어야 합니다.'); return; }
    user.password = newPw;
    save('dal_users', users);
    showToast('비밀번호가 변경되었습니다.');
    e.target.reset();
  });
}

/* ══════════════════════════════════════
   3. Novels (render + bookmarks)
   ══════════════════════════════════════ */
function renderNovels() {
  if (!novelList) return;

  const filtered = novels.filter((novel) => {
    const categoryMatch = activeCategory === 'all' || novel.category === activeCategory;
    const text = `${novel.title} ${novel.summary}`.toLowerCase();
    const searchMatch = !searchKeyword || text.includes(searchKeyword);
    return categoryMatch && searchMatch;
  });

  if (filtered.length === 0) {
    novelList.innerHTML = '<p class="empty-state">검색 결과가 없습니다. 다른 키워드를 입력해보세요.</p>';
    return;
  }

  novelList.innerHTML = filtered.map(novel => {
    const isBookmarked = currentUser && bookmarks.some(b => b.userId === currentUser.id && b.novelId === novel.id);
    return `
    <div class="novel-card-wrap">
      <a class="novel-link" href="${novel.link || '#'}" aria-label="${novel.title} 읽기 페이지 열기">
        <article class="novel-card clickable-card">
          <h3>${escapeHTML(novel.title)}</h3>
          <p>${escapeHTML(novel.summary)}</p>
          <span class="tag">${categoryNames[novel.category] || '연재중'}</span>
        </article>
      </a>
      <button class="bookmark-btn ${isBookmarked ? 'active' : ''}" data-novel-id="${novel.id}" data-novel-title="${escapeHTML(novel.title)}" aria-label="북마크">
        ${isBookmarked ? '&#9733;' : '&#9734;'}
      </button>
    </div>`;
  }).join('');

  novelList.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (!currentUser) { loginDialog?.showModal(); return; }
      const nid = btn.dataset.novelId;
      const idx = bookmarks.findIndex(b => b.userId === currentUser.id && b.novelId === nid);
      if (idx >= 0) {
        bookmarks.splice(idx, 1);
        showToast('북마크가 해제되었습니다.');
      } else {
        bookmarks.push({ userId: currentUser.id, novelId: nid, title: btn.dataset.novelTitle });
        showToast('북마크에 추가되었습니다.');
      }
      save('dal_bookmarks', bookmarks);
      renderNovels();
    });
  });
}

categoryButtons.forEach(button => {
  button.addEventListener('click', () => {
    categoryButtons.forEach(item => { item.classList.remove('active'); item.setAttribute('aria-selected', 'false'); });
    button.classList.add('active');
    button.setAttribute('aria-selected', 'true');
    activeCategory = button.dataset.category;
    renderNovels();
  });
});

novelSearchInput?.addEventListener('input', (e) => {
  searchKeyword = e.target.value.trim().toLowerCase();
  renderNovels();
});

/* ══════════════════════════════════════
   4. Board – CRUD + likes + comments + pagination + inline edit
   ══════════════════════════════════════ */
function savePosts() { save('dal_posts', boardPosts); }

/* Track which comments sections are open */
let openComments = new Set();

/* ── Share image (Canvas API) ── */
function sharePost(post) {
  const S = 1080;
  const cv = document.createElement('canvas');
  cv.width = S; cv.height = S;
  const ctx = cv.getContext('2d');

  // Background
  const bg = ctx.createLinearGradient(0, 0, S, S);
  bg.addColorStop(0, '#1a1a2e'); bg.addColorStop(1, '#16162a');
  ctx.fillStyle = bg; ctx.fillRect(0, 0, S, S);

  // Noise dots
  ctx.fillStyle = 'rgba(255,255,255,0.025)';
  for (let x = 0; x < S; x += 6) for (let y = 0; y < S; y += 6) ctx.fillRect(x, y, 2, 2);

  // Neon border
  ctx.strokeStyle = '#6c63ff'; ctx.lineWidth = 6; ctx.strokeRect(28, 28, S - 56, S - 56);
  ctx.strokeStyle = '#00d4aa'; ctx.lineWidth = 2; ctx.strokeRect(38, 38, S - 76, S - 76);

  // Corner squares
  [[28,28],[S-28,28],[28,S-28],[S-28,S-28]].forEach(([x,y]) => {
    ctx.fillStyle = '#00d4aa'; ctx.fillRect(x-10, y-10, 20, 20);
    ctx.fillStyle = '#1a1a2e'; ctx.fillRect(x-6, y-6, 12, 12);
  });

  // Site title
  ctx.fillStyle = '#6c63ff'; ctx.font = 'bold 27px monospace'; ctx.textAlign = 'center';
  ctx.fillText('▶ 데니스의 아케이드 서재 ◀', S/2, 85);

  // Divider
  ctx.strokeStyle = '#3a3a52'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(60, 105); ctx.lineTo(S-60, 105); ctx.stroke();

  // Author
  ctx.textAlign = 'left'; ctx.fillStyle = '#00d4aa'; ctx.font = 'bold 30px monospace';
  ctx.fillText(`✦ ${post.author}`, 68, 155);

  // Content wrap
  ctx.fillStyle = '#e8e8ec'; ctx.font = '28px sans-serif';
  const maxW = S - 136; const lineH = 46;
  let cy = 206;
  const raw = post.content.length > 600 ? post.content.slice(0, 600) + '…' : post.content;
  let line = '';
  for (const ch of raw) {
    const test = line + ch;
    if (ctx.measureText(test).width > maxW) {
      ctx.fillText(line, 68, cy); cy += lineH; line = ch;
      if (cy > 880) { ctx.fillText('…', 68, cy); break; }
    } else { line = test; }
  }
  if (cy <= 880 && line) ctx.fillText(line, 68, cy);

  // Bottom divider
  ctx.strokeStyle = '#3a3a52'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(60, 928); ctx.lineTo(S-60, 928); ctx.stroke();

  // Stats
  ctx.font = 'bold 26px monospace'; ctx.textAlign = 'left';
  ctx.fillStyle = '#e5484d'; ctx.fillText(`♥ ${post.likes.length}`, 68, 974);
  ctx.fillStyle = '#9a9ab0'; ctx.fillText(`💬 ${post.comments.length}`, 190, 974);

  // Tagline
  ctx.fillStyle = '#6c63ff'; ctx.font = 'italic 21px monospace'; ctx.textAlign = 'right';
  ctx.fillText('INSERT COIN TO READ MORE', S - 68, 1042);

  cv.toBlob(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'arcade-post.png'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }, 'image/png');
  showToast('이미지가 저장되었습니다! 📷');
}

/* ── Report post ── */
function reportPost(postIdx) {
  if (!currentUser) { loginDialog?.showModal(); return; }
  const reports = load('dal_reports', []);
  const postId = boardPosts[postIdx]?.id;
  if (!postId) return;
  if (reports.find(r => r.postId === postId && r.userId === currentUser.id)) {
    showToast('이미 신고한 게시글입니다.'); return;
  }
  reports.push({ postId, userId: currentUser.id, createdAt: Date.now() });
  save('dal_reports', reports);
  showToast('신고가 접수되었습니다. 검토 후 조치하겠습니다.');
}

/* ── Comment helper ── */
function renderCommentItem(c, ci, pidx, currentUser, isAdmin) {
  const factionClass = c.faction === 'B' ? 'comment-item comment-b' : 'comment-item comment-a';
  return `<div class="${factionClass}">
    <span class="comment-author">${escapeHTML(c.author)}</span>
    <span class="comment-text">${escapeHTML(c.content)}</span>
    <span class="comment-time" title="${formatDate(c.createdAt)}">${timeAgo(c.createdAt)}</span>
    ${(currentUser && (c.authorId === currentUser.id || isAdmin)) ? `<button class="icon-btn delete-comment-btn" data-pidx="${pidx}" data-cidx="${ci}" title="삭제">✕</button>` : ''}
  </div>`;
}

/* ── Ranking ── */
function renderRanking() {
  const el = $('#rankingContent');
  if (!el) return;
  const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];

  const topPosts = [...boardPosts].sort((a, b) => b.likes.length - a.likes.length).slice(0, 5);

  const authorMap = {};
  boardPosts.forEach(p => {
    if (!p.author) return;
    if (!authorMap[p.author]) authorMap[p.author] = { likes: 0, posts: 0 };
    authorMap[p.author].likes += p.likes.length;
    authorMap[p.author].posts++;
  });
  const topAuthors = Object.entries(authorMap).sort(([,a],[,b]) => b.likes - a.likes).slice(0, 5);

  const emptyMsg = '<p class="empty-state">아직 데이터가 없습니다.</p>';
  el.innerHTML = `
    <div class="ranking-cols">
      <div class="ranking-col">
        <h3 class="ranking-title">🎖 인기 작가 Top 5</h3>
        ${topAuthors.length === 0 ? emptyMsg : topAuthors.map(([name, s], i) =>
          `<div class="rank-item"><span class="rank-medal">${medals[i]}</span><span class="rank-name">${escapeHTML(name)}</span><span class="rank-score">♥ ${s.likes} · ${s.posts}글</span></div>`
        ).join('')}
      </div>
      <div class="ranking-col">
        <h3 class="ranking-title">🔥 인기 게시글 Top 5</h3>
        ${topPosts.length === 0 ? emptyMsg : topPosts.map((p, i) =>
          `<div class="rank-item"><span class="rank-medal">${medals[i]}</span><span class="rank-name">${escapeHTML(p.content.slice(0, 22))}${p.content.length > 22 ? '…' : ''}</span><span class="rank-score">♥ ${p.likes.length}</span></div>`
        ).join('')}
      </div>
    </div>`;
}

function getSortedIndices() {
  const idx = boardPosts.map((_, i) => i);
  if (boardSort === 'oldest') return idx.slice().reverse();
  if (boardSort === 'popular') return idx.slice().sort((a, b) => boardPosts[b].likes.length - boardPosts[a].likes.length);
  return idx; // newest (posts are prepended via unshift)
}

function renderBoardPosts() {
  if (!boardList) return;

  if (boardPosts.length === 0) {
    boardList.innerHTML = '<p class="empty-state">아직 게시글이 없습니다. 첫 번째 글을 작성해보세요!</p>';
    return;
  }

  const sortedIdx = getSortedIndices();
  const visibleIdx = sortedIdx.slice(0, boardShowCount);
  const hasMore = boardPosts.length > boardShowCount;

  boardList.innerHTML = visibleIdx.map(idx => {
    const post = boardPosts[idx];
    const isOwner = currentUser && (post.authorId === currentUser.id);
    const isAdmin = currentUser && currentUser.role === 'admin';
    const liked = currentUser && post.likes.includes(currentUser.id);
    const dateStr = formatDate(post.createdAt);
    const isOpen = openComments.has(idx);

    return `
    <article class="board-item" data-idx="${idx}">
      <div class="board-item-head">
        <p class="board-meta" title="${dateStr}">작성자: ${escapeHTML(post.author)} · ${timeAgo(post.createdAt)}</p>
        <div class="board-actions">
          <button class="icon-btn share-post-btn" data-idx="${idx}" title="이미지로 공유">📷</button>
          ${currentUser ? `<button class="icon-btn report-btn" data-idx="${idx}" title="신고" style="color:#e5484d;">⚑</button>` : ''}
          ${isOwner ? `<button class="icon-btn edit-post-btn" data-idx="${idx}" title="수정">&#9998;</button>` : ''}
          ${isOwner || isAdmin ? `<button class="icon-btn delete-post-btn" data-idx="${idx}" title="삭제">&#10005;</button>` : ''}
        </div>
      </div>
      <div class="board-content-wrap" id="postWrap${idx}">
        <p class="board-content">${escapeHTML(post.content)}</p>
      </div>
      <div class="board-interact">
        <button class="like-btn ${liked ? 'liked' : ''}" data-idx="${idx}">
          ${liked ? '&#9829;' : '&#9825;'} <span>${post.likes.length}</span>
        </button>
        <button class="comment-toggle-btn" data-idx="${idx}">
          &#128172; <span>${post.comments.length}</span>
        </button>
      </div>
      <div class="comments-section" id="comments${idx}" style="display:${isOpen ? 'block' : 'none'};">
        <div class="colosseum-arena">
          <div class="colosseum-col side-a">
            <div class="col-header col-header-a">⚔ 진실파 <span class="side-count">${post.comments.filter(c=>( c.faction??'A')==='A').length}</span></div>
            ${post.comments.map((c,ci)=>( c.faction??'A')==='A'?renderCommentItem(c,ci,idx,currentUser,isAdmin):'').join('')}
          </div>
          <div class="colosseum-vs">VS</div>
          <div class="colosseum-col side-b">
            <div class="col-header col-header-b">🛡 거짓파 <span class="side-count">${post.comments.filter(c=>c.faction==='B').length}</span></div>
            ${post.comments.map((c,ci)=>c.faction==='B'?renderCommentItem(c,ci,idx,currentUser,isAdmin):'').join('')}
          </div>
        </div>
        ${currentUser ? `
        <div class="faction-select" id="factionSelect${idx}">
          <span class="faction-prompt">진영을 선택하세요:</span>
          <button type="button" class="faction-btn faction-a-btn" data-idx="${idx}" data-faction="A">⚔ 진실파 참전</button>
          <button type="button" class="faction-btn faction-b-btn" data-idx="${idx}" data-faction="B">🛡 거짓파 참전</button>
        </div>
        <form class="comment-form colosseum-form" data-idx="${idx}" id="colosseumForm${idx}" style="display:none;">
          <span class="faction-label" id="factionLabel${idx}"></span>
          <input type="hidden" name="faction" value="A" />
          <input type="text" name="commentContent" placeholder="댓글을 입력하세요..." required />
          <button type="submit" class="btn primary btn-sm">등록</button>
        </form>` : '<p class="login-prompt">댓글을 남기려면 로그인해주세요.</p>'}
      </div>
    </article>`;
  }).join('');

  /* Infinite scroll sentinel */
  if (hasMore) {
    boardList.insertAdjacentHTML('beforeend', `<div class="board-sentinel" id="boardSentinel"></div>`);
    const sentinel = $('#boardSentinel');
    if (sentinel) {
      const io = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
          io.disconnect();
          boardShowCount += boardPageSize;
          renderBoardPosts();
        }
      }, { rootMargin: '120px' });
      io.observe(sentinel);
    }
  }

  /* ── Attach event listeners ── */

  /* Likes */
  boardList.querySelectorAll('.like-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!currentUser) { loginDialog?.showModal(); return; }
      const post = boardPosts[btn.dataset.idx];
      const li = post.likes.indexOf(currentUser.id);
      if (li >= 0) post.likes.splice(li, 1); else post.likes.push(currentUser.id);
      savePosts(); renderBoardPosts(); renderRanking();
    });
  });

  /* Toggle comments */
  boardList.querySelectorAll('.comment-toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.idx);
      if (openComments.has(idx)) openComments.delete(idx);
      else openComments.add(idx);
      const section = $(`#comments${idx}`);
      section.style.display = openComments.has(idx) ? 'block' : 'none';
    });
  });

  /* Faction select → show comment form */
  boardList.querySelectorAll('.faction-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = btn.dataset.idx;
      const faction = btn.dataset.faction;
      const sel = $(`#factionSelect${idx}`);
      const form = $(`#colosseumForm${idx}`);
      const label = $(`#factionLabel${idx}`);
      if (!sel || !form || !label) return;
      sel.style.display = 'none';
      form.style.display = 'flex';
      form.querySelector('input[name="faction"]').value = faction;
      label.textContent = faction === 'A' ? '⚔ 진실파로 참전!' : '🛡 거짓파로 참전!';
      label.className = `faction-label ${faction === 'A' ? 'label-a' : 'label-b'}`;
      form.querySelector('input[name="commentContent"]').focus();
    });
  });

  /* Colosseum comment submit */
  boardList.querySelectorAll('.colosseum-form').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const idx = parseInt(form.dataset.idx);
      const input = form.querySelector('input[name="commentContent"]');
      const faction = form.querySelector('input[name="faction"]').value || 'A';
      const text = input.value.trim();
      if (!text) return;
      boardPosts[idx].comments.push({ author: currentUser.nickname, authorId: currentUser.id, content: text, createdAt: Date.now(), faction });
      openComments.add(idx);
      savePosts(); renderBoardPosts(); renderRanking();
    });
  });

  /* Share post */
  boardList.querySelectorAll('.share-post-btn').forEach(btn => {
    btn.addEventListener('click', () => sharePost(boardPosts[btn.dataset.idx]));
  });

  /* Report post */
  boardList.querySelectorAll('.report-btn').forEach(btn => {
    btn.addEventListener('click', () => reportPost(btn.dataset.idx));
  });

  /* Delete post */
  boardList.querySelectorAll('.delete-post-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!confirm('정말 삭제하시겠습니까?')) return;
      boardPosts.splice(btn.dataset.idx, 1);
      savePosts(); renderBoardPosts();
      showToast('게시글이 삭제되었습니다.');
    });
  });

  /* Inline edit post */
  boardList.querySelectorAll('.edit-post-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = btn.dataset.idx;
      const post = boardPosts[idx];
      const wrap = $(`#postWrap${idx}`);
      if (!wrap) return;

      /* Replace content with inline edit form */
      wrap.innerHTML = `
        <form class="inline-edit-form" data-idx="${idx}">
          <textarea name="editContent" rows="3">${escapeHTML(post.content)}</textarea>
          <div class="inline-edit-actions">
            <button type="submit" class="btn primary btn-sm">저장</button>
            <button type="button" class="btn ghost btn-sm cancel-edit-btn">취소</button>
          </div>
        </form>
      `;

      const editForm = wrap.querySelector('.inline-edit-form');
      const textarea = editForm.querySelector('textarea');
      textarea.focus();
      textarea.setSelectionRange(textarea.value.length, textarea.value.length);

      editForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const newContent = textarea.value.trim();
        if (!newContent) return;
        post.content = newContent;
        savePosts(); renderBoardPosts();
        showToast('게시글이 수정되었습니다.');
      });

      wrap.querySelector('.cancel-edit-btn').addEventListener('click', () => {
        renderBoardPosts();
      });
    });
  });

  /* Delete comment */
  boardList.querySelectorAll('.delete-comment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const pidx = parseInt(btn.dataset.pidx);
      const cidx = btn.dataset.cidx;
      boardPosts[pidx].comments.splice(cidx, 1);
      openComments.add(pidx);
      savePosts(); renderBoardPosts();
    });
  });

}

/* Create post – require login */
boardForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  if (!currentUser) {
    showToast('게시글을 작성하려면 로그인해주세요.');
    loginDialog?.showModal();
    return;
  }
  const fd = new FormData(boardForm);
  const content = fd.get('content').trim();
  if (!content) return;

  boardPosts.unshift({
    id: genId(),
    author: currentUser.nickname,
    authorId: currentUser.id,
    content,
    createdAt: Date.now(),
    likes: [],
    comments: [],
  });
  savePosts();
  showToast('게시글이 등록되었습니다.');
  boardForm.reset();
  if (currentUser) {
    const authorInput = boardForm.querySelector('input[name="author"]');
    if (authorInput) { authorInput.value = currentUser.nickname; }
  }
  boardShowCount = Math.max(boardShowCount, boardPageSize);
  renderBoardPosts();
});

/* ══════════════════════════════════════
   5. Board sort + char counter
   ══════════════════════════════════════ */
$$('.board-sort-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    boardSort = btn.dataset.sort;
    $$('.board-sort-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    boardShowCount = boardPageSize;
    renderBoardPosts();
  });
});

const boardTextarea = boardForm?.querySelector('textarea[name="content"]');
const boardCharCount = $('#boardCharCount');
if (boardTextarea && boardCharCount) {
  boardTextarea.addEventListener('input', () => {
    const len = boardTextarea.value.length;
    boardCharCount.textContent = `${len} / 300자`;
    boardCharCount.classList.toggle('near-limit', len >= 240 && len < 300);
    boardCharCount.classList.toggle('at-limit', len >= 300);
  });
}

/* ══════════════════════════════════════
   6. Side dock panels
   ══════════════════════════════════════ */
function openSidePanel(panelId) {
  $$('.side-panel').forEach(p => p.classList.remove('open'));
  $$('.dock-btn').forEach(b => b.classList.remove('active'));
  const panel = document.getElementById(panelId);
  if (!panel) return;
  panel.classList.add('open');
  $('#sideOverlay')?.classList.add('visible');
  $$('.dock-btn').forEach(b => { if (b.dataset.panel === panelId) b.classList.add('active'); });
  if (panelId === 'panelBoard') renderBoardPosts();
}

function closeSidePanels() {
  $$('.side-panel').forEach(p => p.classList.remove('open'));
  $$('.dock-btn').forEach(b => b.classList.remove('active'));
  $('#sideOverlay')?.classList.remove('visible');
}

$$('.dock-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const panelId = btn.dataset.panel;
    const isOpen = document.getElementById(panelId)?.classList.contains('open');
    if (isOpen) closeSidePanels();
    else openSidePanel(panelId);
  });
});

$$('.side-panel-close').forEach(btn => {
  btn.addEventListener('click', () => closeSidePanels());
});

$$('.open-panel-btn').forEach(btn => {
  btn.addEventListener('click', () => openSidePanel(btn.dataset.panel));
});

$('#sideOverlay')?.addEventListener('click', closeSidePanels);

/* ESC key closes side panels */
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeSidePanels();
});

if (newsletterForm) {
  newsletterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = new FormData(newsletterForm).get('newsletterEmail');
    showToast(`${email} 주소로 뉴스레터 구독이 신청되었습니다.`);
    newsletterForm.reset();
  });
}

/* ══════════════════════════════════════
   7. Hamburger menu
   ══════════════════════════════════════ */
const hamburger = $('.hamburger');
const nav = $('.topbar nav');

if (hamburger && nav) {
  hamburger.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
    hamburger.setAttribute('aria-expanded', isOpen);
  });
  nav.querySelectorAll('a, .nav-action').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    });
  });
}

/* ══════════════════════════════════════
   8. Scroll-to-top
   ══════════════════════════════════════ */
const scrollTopBtn = $('.scroll-top');
if (scrollTopBtn) {
  window.addEventListener('scroll', () => {
    scrollTopBtn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });
  scrollTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

/* ══════════════════════════════════════
   9. Nav active highlight
   ══════════════════════════════════════ */
const navLinks = $$('.topbar nav a[href^="#"]');
const sections = $$('main section[id]');

function updateActiveNav() {
  let current = '';
  sections.forEach(s => { if (window.scrollY >= s.offsetTop - 120) current = s.id; });
  navLinks.forEach(l => l.classList.toggle('active', l.getAttribute('href') === `#${current}`));
}
window.addEventListener('scroll', updateActiveNav, { passive: true });

/* ══════════════════════════════════════
   10. Fade-in
   ══════════════════════════════════════ */
const fadeObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.classList.add('visible'); fadeObserver.unobserve(entry.target); }
  });
}, { threshold: 0.1 });
$$('.panel').forEach(p => fadeObserver.observe(p));

/* ══════════════════════════════════════
   10. Init
   ══════════════════════════════════════ */
updateAuthUI();
renderNovels();
renderBoardPosts();
renderRanking();
